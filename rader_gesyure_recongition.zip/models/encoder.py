import torch
import torch.nn as nn
import torchvision.models as models
import torch.nn.functional as F

class MultiScaleTemporalEncoder(nn.Module):
    """Lightweight multi-scale temporal encoder for sequence features."""

    def __init__(self, in_channels, out_channels, dropout=0.1):
        super(MultiScaleTemporalEncoder, self).__init__()

        # Three temporal receptive fields to capture short/mid/long motion patterns.
        self.branch_k3 = nn.Conv1d(in_channels, out_channels, kernel_size=3, padding=1, bias=False)
        self.branch_k5 = nn.Conv1d(in_channels, out_channels, kernel_size=5, padding=2, bias=False)
        self.branch_d2 = nn.Conv1d(in_channels, out_channels, kernel_size=3, padding=2, dilation=2, bias=False)

        self.fuse = nn.Sequential(
            nn.Conv1d(out_channels * 3, out_channels, kernel_size=1, bias=False),
            nn.BatchNorm1d(out_channels),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout),
        )
        self.residual_proj = nn.Linear(in_channels, out_channels, bias=False) if in_channels != out_channels else None

    def forward(self, x):
        """
        Args:
            x: (B, T, C)
        Returns:
            (B, T, C_out)
        """
        x_res = x
        x = x.transpose(1, 2)  # (B, C, T)

        b1 = self.branch_k3(x)
        b2 = self.branch_k5(x)
        b3 = self.branch_d2(x)
        x_ms = self.fuse(torch.cat([b1, b2, b3], dim=1)).transpose(1, 2)  # (B, T, C_out)

        if self.residual_proj is not None:
            x_res = self.residual_proj(x_res)

        return x_ms + x_res


class FeatureEncoder2D(nn.Module):
    """适用于RT, DT 二维的特征"""
    def __init__(self, fc_size=64, backbone="custom", use_fc=True, input_feature_shape=(1, 48, 64)):
        super(FeatureEncoder2D, self).__init__()
        
        self.backbone = backbone.lower()
        self.use_fc = use_fc
        self.input_feature_shape = input_feature_shape

        if self.backbone not in ["custom", "lenet5"]:
            C, H, W = input_feature_shape
            effective_shape = (3, H, W)
        else:
            effective_shape = input_feature_shape

        if self.backbone == "custom":
            self.feature_extractor = nn.Sequential(
                nn.Conv2d(1, 3, kernel_size=3, stride=1, padding=1),
                nn.BatchNorm2d(3),
                nn.ReLU(inplace=True),
                nn.MaxPool2d(kernel_size=3, stride=2),
                nn.Conv2d(3, 6, kernel_size=3, padding=1),
                nn.BatchNorm2d(6),
                nn.ReLU(inplace=True),
                nn.MaxPool2d(kernel_size=3, stride=2),
            )
        elif self.backbone == "lenet5":
            self.feature_extractor = nn.Sequential(
                nn.Conv2d(1, 6, kernel_size=5, stride=1, padding=2),
                nn.BatchNorm2d(6),
                nn.ReLU(),
                nn.MaxPool2d(kernel_size=2, stride=2),
                nn.Conv2d(6, 16, kernel_size=5, stride=1, padding=0),
                nn.BatchNorm2d(16),
                nn.ReLU(),
                nn.MaxPool2d(kernel_size=2, stride=2),
            )
        else:
            self.feature_extractor = self._load_pretrained_backbone(self.backbone)
            
        self.feature_output_size = self._compute_feature_size(effective_shape)

        if self.use_fc:
            self.fc = nn.Sequential(
                nn.Linear(self.feature_output_size, fc_size),
                nn.LayerNorm(fc_size),
                nn.ReLU(inplace=True),
                nn.Dropout(0.3)
            )

    def _load_pretrained_backbone(self, backbone):
        if backbone == "resnet18":
            model = models.resnet18(weights=None)
            feature_extractor = nn.Sequential(*list(model.children())[:-2])
        elif backbone == "mobilenet":
            model = models.mobilenet_v3_small(weights=None)
            feature_extractor = model.features
        else:
            raise ValueError(f"Unsupported backbone: {backbone}")
        return feature_extractor
    
    def _compute_feature_size(self, input_feature_shape):
        C, H, W = input_feature_shape
        dummy_input = torch.randn(1, C, H, W)
        with torch.no_grad():
            output = self.feature_extractor(dummy_input)
        if output.size(2) <= 0 or output.size(3) <= 0:
            raise ValueError(f"Feature map collapsed! Input: {input_feature_shape}, Output: {output.shape}")
        return output.view(1, -1).size(1)
    
    def forward(self, x):
        if self.backbone not in ["custom", "lenet5"]:
            if x.size(1) == 1:
                x = x.repeat(1, 3, 1, 1)
        x = self.feature_extractor(x)
        if self.use_fc:
            x = x.view(x.size(0), -1)
            x = self.fc(x)
        else:
            x = F.adaptive_avg_pool2d(x, (1, 1))
            x = x.view(x.size(0), -1)
        return x


class FeatureEncoder3D(nn.Module):
    """适用于RDT, ART, ERT 三维的特征
    
    消融实验开关（通过 yaml 配置控制）：
      use_motion_gate : bool  是否使用帧差运动门控模块（默认 True）
      use_mstm        : bool  是否使用多尺度时序卷积模块（默认 True）
      use_attn_pool   : bool  是否使用注意力加权池化（默认 True，False则退回均值池化）
    """
    def __init__(self, cnn_output_size=64, backbone="custom", hidden_size=64,
                 rnn_type='lstm', lstm_layers=1, bidirectional=True, fc_size=64,
                 feature_use_fc=True, input_feature_shape=(1, 64, 64),
                 # ── 消融实验开关 ──────────────────────────────────────────
                 use_motion_gate=True,   # 帧差运动门控
                 use_mstm=True,          # 多尺度时序卷积
                 use_attn_pool=True,     # 注意力加权池化
                 # ─────────────────────────────────────────────────────────
                 ):
        super(FeatureEncoder3D, self).__init__()

        # 保存消融开关
        self.use_motion_gate = bool(use_motion_gate)
        self.use_mstm        = bool(use_mstm)
        self.use_attention   = bool(use_attn_pool)

        input_feature_shape_2D = input_feature_shape[1:]
        self.feature_extractor = FeatureEncoder2D(
            fc_size=cnn_output_size,
            backbone=backbone,
            use_fc=feature_use_fc,
            input_feature_shape=input_feature_shape_2D
        )

        rnn_input_size = cnn_output_size

        # ── 多尺度时序卷积模块 MSTM ──────────────────────────────────────
        # 始终初始化（消融关闭时 forward 里跳过，不影响其他参数）
        self.temporal_encoder = MultiScaleTemporalEncoder(
            in_channels=rnn_input_size,
            out_channels=rnn_input_size,
            dropout=0.1,
        )

        # ── 帧差运动门控模块 ──────────────────────────────────────────────
        # 始终初始化
        self.delta_proj = nn.Sequential(
            nn.Linear(rnn_input_size, rnn_input_size),
            nn.Tanh(),
        )
        self.motion_gate = nn.Sequential(
            nn.Linear(rnn_input_size * 2, rnn_input_size),
            nn.Sigmoid(),
        )
        self.delta_norm = nn.LayerNorm(rnn_input_size)
        self.motion_scale = 0.2

        # ── 双向 LSTM ─────────────────────────────────────────────────────
        if rnn_type.lower() == 'lstm':
            self.rnn = nn.LSTM(input_size=rnn_input_size, hidden_size=hidden_size,
                               num_layers=lstm_layers, bidirectional=bidirectional,
                               batch_first=True)
        elif rnn_type.lower() == 'gru':
            self.rnn = nn.GRU(input_size=rnn_input_size, hidden_size=hidden_size,
                              num_layers=lstm_layers, bidirectional=bidirectional,
                              batch_first=True)
        else:
            self.rnn = nn.RNN(input_size=rnn_input_size, hidden_size=hidden_size,
                              num_layers=lstm_layers, bidirectional=bidirectional,
                              batch_first=True)

        # ── FC 降维层 ─────────────────────────────────────────────────────
        self.fc = nn.Sequential(
            nn.Linear(hidden_size * 2 if bidirectional else hidden_size, fc_size),
            nn.ReLU(inplace=True),
            nn.Dropout(0.3)
        )

        # ── 注意力加权池化 ────────────────────────────────────────────────
        # 始终初始化；use_attention=False 时 forward 里用均值池化替代
        if bidirectional:
            self.attention = nn.Linear(hidden_size * 2, 1)
        else:
            self.attention = nn.Linear(hidden_size, 1)

    def forward(self, x):
        batch_size, seq_len, channels, height, width = x.size()
        x = x.view(batch_size * seq_len, channels, height, width)
        cnn_features = self.feature_extractor(x)
        cnn_features = cnn_features.view(cnn_features.size(0), -1)

        actual_rnn_input_size = cnn_features.size(1)
        rnn_input = cnn_features.view(batch_size, seq_len, actual_rnn_input_size)

        # ── ① 帧差运动门控（消融开关：use_motion_gate）───────────────────
        if self.use_motion_gate:
            delta = rnn_input[:, 1:, :] - rnn_input[:, :-1, :]
            delta = F.pad(delta, (0, 0, 1, 0))          # 补齐首帧，保持时序长度
            delta_feat = self.delta_proj(delta)
            delta_feat = self.delta_norm(delta_feat)
            motion_gate = self.motion_gate(torch.cat([rnn_input, delta_feat], dim=-1))
            rnn_input = rnn_input + self.motion_scale * motion_gate * delta_feat
            rnn_input = torch.nan_to_num(rnn_input, nan=0.0, posinf=1e3, neginf=-1e3)

        # ── ② 多尺度时序卷积 MSTM（消融开关：use_mstm）─────────────────
        if self.use_mstm:
            rnn_input = self.temporal_encoder(rnn_input)
            rnn_input = torch.nan_to_num(rnn_input, nan=0.0, posinf=1e3, neginf=-1e3)

        # ── ③ 双向 LSTM ───────────────────────────────────────────────────
        rnn_output, _ = self.rnn(rnn_input)

        # ── ④ 注意力加权池化 vs 均值池化（消融开关：use_attn_pool）───────
        if self.use_attention:
            attention_weights = F.softmax(self.attention(rnn_output), dim=1)
            final_output = (rnn_output * attention_weights).sum(dim=1)
        else:
            final_output = rnn_output.mean(dim=1)        # 关闭时退回均值池化

        output = self.fc(final_output)
        return output