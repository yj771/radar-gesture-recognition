import torch
import torch.nn as nn


class CSAMBlock(nn.Module):
    """
    Multi-Cross Self-Attention (MCSA) block used in CSAM.
    Multi-scale conv fusion + channel attention + spatial attention.
    """

    def __init__(self, in_channels, reduction=16):
        super(CSAMBlock, self).__init__()
        reduced_channels = max(1, in_channels // reduction)

        self.branch1 = nn.Sequential(
            nn.Conv2d(in_channels, in_channels, kernel_size=1, bias=False),
            nn.BatchNorm2d(in_channels),
            nn.ReLU(inplace=True),
        )
        self.branch3 = nn.Sequential(
            nn.Conv2d(in_channels, in_channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(in_channels),
            nn.ReLU(inplace=True),
        )
        self.branch5 = nn.Sequential(
            nn.Conv2d(in_channels, in_channels, kernel_size=5, padding=2, bias=False),
            nn.BatchNorm2d(in_channels),
            nn.ReLU(inplace=True),
        )

        self.channel_attn = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(in_channels, reduced_channels, 1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(reduced_channels, in_channels, 1, bias=False),
            nn.Sigmoid(),
        )

        self.spatial_attn = nn.Sequential(
            nn.Conv2d(2, 1, kernel_size=7, padding=3, bias=False),
            nn.Sigmoid(),
        )

    def forward(self, x):
        x_ms = self.branch1(x) + self.branch3(x) + self.branch5(x)
        x_ca = x_ms * self.channel_attn(x_ms)
        avg_map = torch.mean(x_ca, dim=1, keepdim=True)
        max_map, _ = torch.max(x_ca, dim=1, keepdim=True)
        spatial_map = self.spatial_attn(torch.cat([avg_map, max_map], dim=1))
        return x_ca * spatial_map
