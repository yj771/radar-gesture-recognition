import torch
import torch.nn as nn

from models.methods.reverse_gradient import DomainAdversarialNetwork
from models.encoder import FeatureEncoder2D, FeatureEncoder3D
from models.decoder import ConcatDecoder, AttentionDecoder


class VerticalDiscriminator(nn.Module):
    """
    轻量垂直方向判别器：专注于区分 Down(0) vs Other(1) vs Up(2)
    只使用RDT+ERT两个对垂直运动最敏感的特征
    """

    def __init__(self, input_dim, hidden_dim=128, dropout=0.15):
        super().__init__()
        # 两层MLP + LayerNorm + GELU，轻量设计避免过拟合
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.LayerNorm(hidden_dim // 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim // 2, 3),  # [Down, Other, Up]
        )

    def forward(self, x):
        return self.net(x)


class MultiViewFeatureFusion(nn.Module):
    """Multi-view feature fusion network for RT/DT/RDT/ERT/ART features."""

    def __init__(
        self,
        backbone="custom",
        cnn_output_size=128,
        hidden_size=128,
        rnn_type='lstm',
        lstm_layers=1,
        bidirectional=True,
        fc_size=7,
        num_domains=5,
        input_feature_shapes=None,
        fusion_mode='concatenate',
        method='add',
        is_sharedspecific=0,
        bottleneck_dim=None,
        selected_features=None,
        is_domain_loss=0,
        num_classes=7,
        use_vertical_discriminator=False,
        vertical_hidden_dim=96,  # 降低hidden_dim减少参数
        vertical_gate_init=-2.5,  # 更保守的初始化
        vertical_blend_scale=0.15,  # 降低blend强度
        vertical_down_class=2,
        vertical_up_class=6,
        use_motion_gate=True,
        use_mstm=True,
        use_attn_pool=True,
    ):
        super().__init__()

        self.fusion_mode = fusion_mode
        self.method = method
        self.bottleneck_dim = bottleneck_dim
        self.selected_features = selected_features if selected_features else ['RT', 'DT', 'RDT', 'ERT', 'ART']
        self.num_views = len(self.selected_features)
        self.vertical_down_class = int(vertical_down_class)
        self.vertical_up_class = int(vertical_up_class)
        self.vertical_other_index = 1
        self.vertical_blend_scale = float(vertical_blend_scale)

        self.use_motion_gate = bool(use_motion_gate)
        self.use_mstm = bool(use_mstm)
        self.use_attn_pool = bool(use_attn_pool)

        self.use_vertical_discriminator = bool(use_vertical_discriminator)
        if self.use_vertical_discriminator:
            required_features = {'RDT', 'ERT'}
            if not required_features.issubset(set(self.selected_features)):
                raise ValueError("use_vertical_discriminator=True requires both 'RDT' and 'ERT' in selected_features.")

        self.encoders = nn.ModuleDict()
        for feature in self.selected_features:
            if feature in ['RT', 'DT']:
                self.encoders[feature] = FeatureEncoder2D(
                    fc_size=cnn_output_size,
                    backbone=backbone,
                    use_fc=True,
                    input_feature_shape=input_feature_shapes[feature],
                )
            elif feature in ['RDT', 'ERT', 'ART']:
                self.encoders[feature] = FeatureEncoder3D(
                    cnn_output_size=cnn_output_size,
                    backbone=backbone,
                    hidden_size=hidden_size,
                    rnn_type=rnn_type,
                    lstm_layers=lstm_layers,
                    bidirectional=bidirectional,
                    fc_size=cnn_output_size,
                    feature_use_fc=True,
                    input_feature_shape=input_feature_shapes[feature],
                    use_motion_gate=self.use_motion_gate,
                    use_mstm=self.use_mstm,
                    use_attn_pool=self.use_attn_pool,
                )
            else:
                raise ValueError("Unsupported feature type: {}. Choose from 'RT', 'DT', 'RDT', 'ERT', 'ART'.".format(feature))

        feature_dim = cnn_output_size

        if fusion_mode == 'concatenate':
            self.decoder = ConcatDecoder(feature_dim, num_views=self.num_views, method=method)
        elif fusion_mode == 'attention':
            self.decoder = AttentionDecoder(
                feature_dim,
                num_views=self.num_views,
                is_sharedspecific=is_sharedspecific,
                method=method,
                num_classes=num_classes,
                selected_features=self.selected_features,
            )
        else:
            raise ValueError("Invalid fusion mode: {}. Choose from 'concatenate' or 'attention'.".format(fusion_mode))

        self.fc_fusion = nn.Sequential(
            nn.Linear(feature_dim, fc_size),
            nn.ReLU(inplace=True),
            nn.Dropout(),
        )
        self.classifier = nn.Sequential()

        if self.use_vertical_discriminator:
            self.vertical_discriminator = VerticalDiscriminator(
                input_dim=feature_dim * 2,  # RDT + ERT
                hidden_dim=int(vertical_hidden_dim),
                dropout=0.15,
            )
            # 可学习blend gate：控制垂直判别器对主分类器的影响
            self.vertical_blend_gate = nn.Parameter(torch.tensor(float(vertical_gate_init)))

        if is_domain_loss:
            self.domain_discriminator = DomainAdversarialNetwork(
                feature_dim=feature_dim,
                num_domains=num_domains,
                method=method,
                num_views=self.num_views,
            )

    def forward(self, features):
        if not set(features.keys()).issubset(set(self.selected_features)):
            raise ValueError("Input features ({}) don't match selected features ({}).".format(features.keys(), self.selected_features))

        encoded_features = []
        encoded_feature_map = {}
        for feature_name in self.selected_features:
            encoded_feature = self.encoders[feature_name](features[feature_name])
            encoded_features.append(encoded_feature)
            encoded_feature_map[feature_name] = encoded_feature

        vertical_logits = None
        if self.use_vertical_discriminator:
            # 只使用RDT + ERT特征，这两个对垂直方向最敏感
            vertical_input = torch.cat([encoded_feature_map['RDT'], encoded_feature_map['ERT']], dim=1)
            vertical_logits = self.vertical_discriminator(vertical_input)

        if self.method == 'DScombine':
            alphas, alpha_combined, u_a, u_tensor = self.decoder(*encoded_features)
            return encoded_features, alphas, alpha_combined, u_a, u_tensor

        fused_features, weights = self.decoder(*encoded_features)
        final_features = self.fc_fusion(fused_features)
        outputs = self.classifier(final_features)

        # ✅ 修复：使用log-space blend避免破坏softmax归一化
        if vertical_logits is not None:
            # 计算垂直判别器的log概率
            vert_log_prob = torch.log_softmax(vertical_logits, dim=1)
            main_log_prob = torch.log_softmax(outputs, dim=1)
            
            # gate控制垂直判别器的混合强度
            gate = torch.sigmoid(self.vertical_blend_gate) * self.vertical_blend_scale
            
            # 在log空间混合：log(p_main * p_vert^gate) = log(p_main) + gate * log(p_vert)
            # 只对Down/Up两类进行blend
            blended_log_prob = main_log_prob.clone()
            blended_log_prob[:, self.vertical_down_class] = (
                main_log_prob[:, self.vertical_down_class] + gate * vert_log_prob[:, 0]
            )
            blended_log_prob[:, self.vertical_up_class] = (
                main_log_prob[:, self.vertical_up_class] + gate * vert_log_prob[:, 2]
            )
            
            # 转回logits用于loss计算（保持数值稳定性）
            outputs = blended_log_prob - torch.logsumexp(blended_log_prob, dim=1, keepdim=True)

        return outputs, weights, fused_features, vertical_logits