import torch
import torch.nn as nn

from .csam import CSAMBlock
from .enhanced_csam import EnhancedCSAMBlock, MultiHeadCrossAttention, EnhancedCSAMDecoder

from models.methods.attention import (
    MultiViewLinearProjectionAttention,
    MultiViewSEAttention,
    MultiViewECAAttention,
    AdaptiveMultiViewAttention,
    MultiViewDSFusion,
    MultiViewCrossAttentionWrapper,
)


class CSAMDecoder(nn.Module):
    """
    CSAM decoder adapted for multi-view radar fusion.

    Design for 5-view setup:
    1) Ring pair fusion: fuse (v0,v1),(v1,v2)...(v4,v0) with MCSA.
    2) Global refinement: fuse stage-1 result with view-weighted global context.
    3) Token refinement: transformer over original views + stage tokens.
    """

    def __init__(self, feature_dim, num_views=None, is_sharedspecific=False):
        super().__init__()
        self.feature_dim = feature_dim
        self.num_views = num_views if num_views is not None else 5

        self.mcsa_stage1 = CSAMBlock(feature_dim * 2)
        self.mcsa_stage2 = CSAMBlock(feature_dim * 2)
        self.pool = nn.AdaptiveAvgPool2d(1)

        pair_hidden = max(32, feature_dim // 2)
        self.pair_score_fc = nn.Sequential(
            nn.Linear(feature_dim * 2, pair_hidden),
            nn.ReLU(inplace=True),
            nn.Linear(pair_hidden, 1),
        )

        nhead = 4 if feature_dim % 4 == 0 else 2
        transformer_layer = nn.TransformerEncoderLayer(
            d_model=feature_dim,
            nhead=nhead,
            dim_feedforward=feature_dim * 4,
            dropout=0.1,
            batch_first=True,
        )
        self.transformer = nn.TransformerEncoder(transformer_layer, num_layers=1)

        token_hidden = max(32, feature_dim // 2)
        self.token_score_fc = nn.Sequential(
            nn.Linear(feature_dim, token_hidden),
            nn.ReLU(inplace=True),
            nn.Linear(token_hidden, 1),
        )

        self.final_proj = nn.Sequential(
            nn.Linear(feature_dim * 2, feature_dim),
            nn.LayerNorm(feature_dim),
            nn.ReLU(inplace=True),
        )
        self.view_weights_fc = nn.Sequential(
            nn.Linear(feature_dim * self.num_views, 128),
            nn.ReLU(inplace=True),
            nn.Linear(128, self.num_views),
            nn.Softmax(dim=-1),
        )

    def _mcsa_pair_fusion(self, left, right, block):
        pair = torch.cat([left, right], dim=-1).unsqueeze(-1).unsqueeze(-1)
        fused_pair = block(pair)
        fused_pair = self.pool(fused_pair).squeeze(-1).squeeze(-1)
        left_part, right_part = torch.chunk(fused_pair, 2, dim=-1)
        pair_mean = 0.5 * (left + right)
        return 0.5 * (left_part + right_part) + 0.5 * pair_mean

    def _ring_pair_fusion(self, x_list):
        pair_features = []
        pair_scores = []
        view_count = len(x_list)

        for idx in range(view_count):
            left = x_list[idx]
            right = x_list[(idx + 1) % view_count]
            pair_features.append(self._mcsa_pair_fusion(left, right, self.mcsa_stage1))
            pair_scores.append(self.pair_score_fc(torch.cat([left, right], dim=-1)))

        pair_stack = torch.stack(pair_features, dim=1)
        score_stack = torch.stack(pair_scores, dim=1).squeeze(-1)
        pair_weights = torch.softmax(score_stack, dim=1).unsqueeze(-1)
        return torch.sum(pair_stack * pair_weights, dim=1)

    def forward(self, views):
        if isinstance(views, (list, tuple)):
            x_list = list(views)
        else:
            x_list = [views]

        if len(x_list) == 0:
            raise ValueError("No views provided")
        if len(x_list) < 2:
            raise ValueError("CSAMDecoder expects at least two views")
        if len(x_list) != self.num_views:
            raise ValueError(f"Expected {self.num_views} views, got {len(x_list)}")

        concatenated = torch.cat(x_list, dim=-1)
        view_weights = self.view_weights_fc(concatenated)

        stacked_views = torch.stack(x_list, dim=1)
        weighted_global = torch.sum(stacked_views * view_weights.unsqueeze(-1), dim=1)

        stage1_feature = self._ring_pair_fusion(x_list)
        stage2_feature = self._mcsa_pair_fusion(stage1_feature, weighted_global, self.mcsa_stage2)

        tokens = torch.cat(
            [stacked_views, stage1_feature.unsqueeze(1), stage2_feature.unsqueeze(1)],
            dim=1,
        )
        refined_tokens = self.transformer(tokens)

        token_scores = self.token_score_fc(refined_tokens).squeeze(-1)
        token_weights = torch.softmax(token_scores, dim=1).unsqueeze(-1)
        fused_token = torch.sum(refined_tokens * token_weights, dim=1)
        global_token = refined_tokens.mean(dim=1)

        fused_output = self.final_proj(torch.cat([fused_token, global_token], dim=-1))
        return fused_output, view_weights


class HeteroCSAMDecoder(nn.Module):
    """CSAM variant for mixed 2D/3D views while preserving CSAM decode backbone."""

    def __init__(
        self,
        feature_dim,
        num_views=None,
        is_sharedspecific=False,
        selected_features=None,
        use_view_gain=True,
        use_view_embedding=False,
        use_view_bias=True,
    ):
        super().__init__()
        self.feature_dim = feature_dim
        self.num_views = num_views if num_views is not None else 5
        self.selected_features = list(selected_features) if selected_features else ["RT", "DT", "RDT", "ERT", "ART"]
        self.use_view_gain = use_view_gain
        self.use_view_embedding = use_view_embedding
        self.use_view_bias = use_view_bias

        expected = {"RT", "DT", "RDT", "ERT", "ART"}
        if set(self.selected_features) != expected:
            raise ValueError(
                f"csam_hetero expects selected_features to be exactly {sorted(expected)}, got {self.selected_features}"
            )

        self.idx_2d = [i for i, name in enumerate(self.selected_features) if name in {"RT", "DT"}]
        self.idx_3d = [i for i, name in enumerate(self.selected_features) if name in {"RDT", "ERT", "ART"}]

        if self.use_view_embedding:
            # Keep the identity prior lightweight so hetero baseline behavior is preserved.
            self.view_embedding = nn.Parameter(torch.zeros(1, self.num_views, feature_dim))
        else:
            self.register_parameter("view_embedding", None)

        self.view_weights_fc = nn.Sequential(
            nn.Linear(feature_dim * self.num_views, 128),
            nn.ReLU(inplace=True),
            nn.Linear(128, self.num_views),
            nn.Softmax(dim=-1),
        )
        self.intra2d_score = nn.Sequential(
            nn.Linear(feature_dim * len(self.idx_2d), 64),
            nn.ReLU(inplace=True),
            nn.Linear(64, len(self.idx_2d)),
        )
        self.intra3d_score = nn.Sequential(
            nn.Linear(feature_dim * len(self.idx_3d), 64),
            nn.ReLU(inplace=True),
            nn.Linear(64, len(self.idx_3d)),
        )

        self.cross_modal_mcsa = CSAMBlock(feature_dim * 2)
        self.pool = nn.AdaptiveAvgPool2d(1)

        nhead = 4 if feature_dim % 4 == 0 else 2
        layer = nn.TransformerEncoderLayer(
            d_model=feature_dim,
            nhead=nhead,
            dim_feedforward=feature_dim * 4,
            dropout=0.1,
            batch_first=True,
        )
        self.transformer = nn.TransformerEncoder(layer, num_layers=1)
        hidden = max(32, feature_dim // 2)
        self.token_score_fc = nn.Sequential(
            nn.Linear(feature_dim, hidden),
            nn.ReLU(inplace=True),
            nn.Linear(hidden, 1),
        )
        self.final_proj = nn.Sequential(
            nn.Linear(feature_dim * 2, feature_dim),
            nn.LayerNorm(feature_dim),
            nn.ReLU(inplace=True),
        )

    def _weighted_group_fusion(self, stacked_views, group_indices, scorer):
        group_tokens = stacked_views[:, group_indices, :]
        logits = scorer(group_tokens.reshape(group_tokens.size(0), -1))
        weights = torch.softmax(logits, dim=-1).unsqueeze(-1)
        return torch.sum(group_tokens * weights, dim=1)

    def _cross_modal_fusion(self, token2d, token3d):
        pair = torch.cat([token2d, token3d], dim=-1).unsqueeze(-1).unsqueeze(-1)
        fused_pair = self.cross_modal_mcsa(pair)
        fused_pair = self.pool(fused_pair).squeeze(-1).squeeze(-1)
        left, right = torch.chunk(fused_pair, 2, dim=-1)
        return 0.5 * (left + right)

    def forward(self, views):
        x_list = list(views) if isinstance(views, (list, tuple)) else [views]
        if len(x_list) != self.num_views:
            raise ValueError(f"Expected {self.num_views} views, got {len(x_list)}")

        stacked_views = torch.stack(x_list, dim=1)
        if self.use_view_embedding:
            stacked_views = stacked_views + self.view_embedding

        concatenated = stacked_views.reshape(stacked_views.size(0), -1)
        view_weights = self.view_weights_fc(concatenated)
        weighted_global = torch.sum(stacked_views * view_weights.unsqueeze(-1), dim=1)

        fused_2d = self._weighted_group_fusion(stacked_views, self.idx_2d, self.intra2d_score)
        fused_3d = self._weighted_group_fusion(stacked_views, self.idx_3d, self.intra3d_score)
        cross_modal = self._cross_modal_fusion(fused_2d, fused_3d)

        tokens = torch.cat(
            [
                stacked_views,
                fused_2d.unsqueeze(1),
                fused_3d.unsqueeze(1),
                cross_modal.unsqueeze(1),
                weighted_global.unsqueeze(1),
            ],
            dim=1,
        )
        refined = self.transformer(tokens)
        token_scores = self.token_score_fc(refined).squeeze(-1)
        token_weights = torch.softmax(token_scores, dim=1).unsqueeze(-1)
        fused_token = torch.sum(refined * token_weights, dim=1)
        global_token = refined.mean(dim=1)
        fused_output = self.final_proj(torch.cat([fused_token, global_token], dim=-1))
        return fused_output, view_weights


class MultiScaleTokenProjector(nn.Module):
    """Lightweight multi-scale projector for token features (B, C)."""

    def __init__(self, feature_dim):
        super().__init__()
        mid = max(16, feature_dim // 2)
        low = max(8, feature_dim // 4)
        self.branch_1 = nn.Linear(feature_dim, feature_dim)
        self.branch_2 = nn.Sequential(
            nn.Linear(feature_dim, mid),
            nn.ReLU(inplace=True),
            nn.Linear(mid, feature_dim),
        )
        self.branch_3 = nn.Sequential(
            nn.Linear(feature_dim, low),
            nn.ReLU(inplace=True),
            nn.Linear(low, feature_dim),
        )
        self.fuse = nn.Sequential(
            nn.Linear(feature_dim * 3, feature_dim),
            nn.LayerNorm(feature_dim),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        b1 = self.branch_1(x)
        b2 = self.branch_2(x)
        b3 = self.branch_3(x)
        return self.fuse(torch.cat([b1, b2, b3], dim=-1))



class DomainGeneralizedCSAMDecoder(nn.Module):
    """5-view CSAM decoder with MPFF + MCSA + 4-layer transformer."""

    def __init__(
        self,
        feature_dim,
        num_views=None,
        is_sharedspecific=False,
        selected_features=None,
        use_view_gain=True,
        use_view_embedding=True,
        use_view_bias=True,
    ):
        super().__init__()
        self.feature_dim = feature_dim
        self.num_views = num_views if num_views is not None else 5
        self.selected_features = list(selected_features) if selected_features else ["RT", "DT", "RDT", "ERT", "ART"]

        self.use_view_gain = use_view_gain
        self.use_view_embedding = use_view_embedding
        self.use_view_bias = use_view_bias

        expected = {"RT", "DT", "RDT", "ERT", "ART"}
        if set(self.selected_features) != expected:
            raise ValueError(
                f"csam_domain_generalized expects selected_features to be exactly {sorted(expected)}, got {self.selected_features}"
            )

        self.mpff = nn.ModuleList([MultiScaleTokenProjector(feature_dim) for _ in range(self.num_views)])

        init_gain = []
        for name in self.selected_features:
            if name == "ERT":
                init_gain.append(1.08)
            elif name == "ART":
                init_gain.append(1.04)
            else:
                init_gain.append(1.00)
        self.view_gain = nn.Parameter(torch.tensor(init_gain, dtype=torch.float32))
        # Learnable view identity to avoid token homogenization across 5 views.
        self.view_embedding = nn.Parameter(torch.zeros(1, self.num_views, feature_dim))

        nhead = 4 if feature_dim % 4 == 0 else 2
        self.msa_norm = nn.LayerNorm(feature_dim)
        self.msa = nn.MultiheadAttention(embed_dim=feature_dim, num_heads=nhead, dropout=0.1, batch_first=True)
        self.cross_attn = nn.MultiheadAttention(embed_dim=feature_dim, num_heads=nhead, dropout=0.1, batch_first=True)
        self.cross_norm = nn.LayerNorm(feature_dim)

        layer = nn.TransformerEncoderLayer(
            d_model=feature_dim,
            nhead=nhead,
            dim_feedforward=feature_dim * 4,
            dropout=0.1,
            batch_first=True,
        )
        self.transformer = nn.TransformerEncoder(layer, num_layers=4)

        self.view_weights_fc = nn.Sequential(
            nn.Linear(feature_dim * self.num_views, 128),
            nn.ReLU(inplace=True),
            nn.Linear(128, self.num_views),
        )

        bias_init = []
        for name in self.selected_features:
            if name == "ERT":
                bias_init.append(0.182322)  # ln(1.2)
            elif name == "ART":
                bias_init.append(0.095310)  # ln(1.1)
            else:
                bias_init.append(0.0)
        self.view_attention_bias = nn.Parameter(torch.tensor(bias_init, dtype=torch.float32))
        # Weak-start gate (~0.10) for attention bias; lets bias grow gradually.
        self.view_bias_gate = nn.Parameter(torch.full((self.num_views,), -2.2, dtype=torch.float32))

        hidden = max(32, feature_dim // 2)
        self.token_score_fc = nn.Sequential(
            nn.Linear(feature_dim, hidden),
            nn.ReLU(inplace=True),
            nn.Linear(hidden, 1),
        )
        self.final_proj = nn.Sequential(
            nn.Linear(feature_dim * 2, feature_dim),
            nn.LayerNorm(feature_dim),
            nn.ReLU(inplace=True),
        )

    def _mpff(self, x_list):
        enhanced = []
        if self.use_view_gain:
            gain = torch.clamp(self.view_gain, min=0.5, max=2.0)
        else:
            gain = torch.ones_like(self.view_gain)
        for idx, token in enumerate(x_list):
            enhanced.append(self.mpff[idx](token) * gain[idx])
        return torch.stack(enhanced, dim=1)

    def _mcsa(self, tokens):
        normed = self.msa_norm(tokens)
        self_attn, _ = self.msa(normed, normed, normed)
        denoised = tokens + self_attn

        cross_outputs = []
        view_count = denoised.size(1)
        for i in range(view_count):
            query = denoised[:, i : i + 1, :]
            others = torch.cat([denoised[:, :i, :], denoised[:, i + 1 :, :]], dim=1)
            if others.size(1) == 0:
                cross_outputs.append(query)
                continue
            attended, _ = self.cross_attn(query, others, others)
            cross_outputs.append(attended)
        cross_tokens = torch.cat(cross_outputs, dim=1)
        return self.cross_norm(denoised + cross_tokens)

    def forward(self, views):
        x_list = list(views) if isinstance(views, (list, tuple)) else [views]
        if len(x_list) != self.num_views:
            raise ValueError(f"Expected {self.num_views} views, got {len(x_list)}")

        mpff_tokens = self._mpff(x_list)
        if self.use_view_embedding:
            mpff_tokens = mpff_tokens + self.view_embedding
        mcsa_tokens = self._mcsa(mpff_tokens)
        refined = self.transformer(mcsa_tokens)

        concat_flat = refined.reshape(refined.size(0), -1)
        view_logits = self.view_weights_fc(concat_flat)
        if self.use_view_bias:
            gated_bias = torch.sigmoid(self.view_bias_gate) * self.view_attention_bias
            view_logits = view_logits + gated_bias.unsqueeze(0)
        view_weights = torch.softmax(view_logits, dim=-1)

        weighted_view_token = torch.sum(refined * view_weights.unsqueeze(-1), dim=1)
        token_scores = self.token_score_fc(refined).squeeze(-1)
        token_weights = torch.softmax(token_scores, dim=1).unsqueeze(-1)
        fused_token = torch.sum(refined * token_weights, dim=1)

        fused_output = self.final_proj(torch.cat([fused_token, weighted_view_token], dim=-1))
        return fused_output, view_weights


class DomainGeneralizedHierCSAMDecoder(nn.Module):
    """Hierarchical 5-view CSAM: per-view MPFF -> intra-group fusion -> cross-group interaction -> transformer."""

    def __init__(self, feature_dim, num_views=None, is_sharedspecific=False, selected_features=None):
        super().__init__()
        self.feature_dim = feature_dim
        self.num_views = num_views if num_views is not None else 5
        self.selected_features = list(selected_features) if selected_features else ["RT", "DT", "RDT", "ERT", "ART"]

        expected = {"RT", "DT", "RDT", "ERT", "ART"}
        if set(self.selected_features) != expected:
            raise ValueError(
                f"csam_domain_generalized_hier expects selected_features to be exactly {sorted(expected)}, got {self.selected_features}"
            )

        self.idx_2d = [i for i, name in enumerate(self.selected_features) if name in {"RT", "DT"}]
        self.idx_3d = [i for i, name in enumerate(self.selected_features) if name in {"RDT", "ERT", "ART"}]

        self.mpff = nn.ModuleList([MultiScaleTokenProjector(feature_dim) for _ in range(self.num_views)])
        self.view_embedding = nn.Parameter(torch.zeros(1, self.num_views, feature_dim))

        nhead = 4 if feature_dim % 4 == 0 else 2
        self.msa_norm = nn.LayerNorm(feature_dim)
        self.msa = nn.MultiheadAttention(embed_dim=feature_dim, num_heads=nhead, dropout=0.1, batch_first=True)

        self.intra2d_score = nn.Sequential(
            nn.Linear(feature_dim * len(self.idx_2d), 64),
            nn.ReLU(inplace=True),
            nn.Linear(64, len(self.idx_2d)),
        )
        self.intra3d_score = nn.Sequential(
            nn.Linear(feature_dim * len(self.idx_3d), 64),
            nn.ReLU(inplace=True),
            nn.Linear(64, len(self.idx_3d)),
        )

        self.cross_attn = nn.MultiheadAttention(embed_dim=feature_dim, num_heads=nhead, dropout=0.1, batch_first=True)
        self.cross_norm = nn.LayerNorm(feature_dim)

        layer = nn.TransformerEncoderLayer(
            d_model=feature_dim,
            nhead=nhead,
            dim_feedforward=feature_dim * 4,
            dropout=0.1,
            batch_first=True,
        )
        self.transformer = nn.TransformerEncoder(layer, num_layers=4)

        self.view_weights_fc = nn.Sequential(
            nn.Linear(feature_dim * self.num_views, 128),
            nn.ReLU(inplace=True),
            nn.Linear(128, self.num_views),
        )
        bias_init = []
        for name in self.selected_features:
            if name == "ERT":
                bias_init.append(0.182322)  # ln(1.2)
            elif name == "ART":
                bias_init.append(0.095310)  # ln(1.1)
            else:
                bias_init.append(0.0)
        self.view_attention_bias = nn.Parameter(torch.tensor(bias_init, dtype=torch.float32))
        self.view_bias_gate = nn.Parameter(torch.full((self.num_views,), -2.2, dtype=torch.float32))

        hidden = max(32, feature_dim // 2)
        self.token_score_fc = nn.Sequential(
            nn.Linear(feature_dim, hidden),
            nn.ReLU(inplace=True),
            nn.Linear(hidden, 1),
        )
        self.final_proj = nn.Sequential(
            nn.Linear(feature_dim * 2, feature_dim),
            nn.LayerNorm(feature_dim),
            nn.ReLU(inplace=True),
        )

    def _weighted_group_fusion(self, stacked_views, group_indices, scorer):
        group_tokens = stacked_views[:, group_indices, :]
        logits = scorer(group_tokens.reshape(group_tokens.size(0), -1))
        weights = torch.softmax(logits, dim=-1).unsqueeze(-1)
        fused = torch.sum(group_tokens * weights, dim=1)
        return fused, weights.squeeze(-1)

    def _domain_msa(self, tokens):
        normed = self.msa_norm(tokens)
        self_attn, _ = self.msa(normed, normed, normed)
        return tokens + self_attn

    def forward(self, views):
        x_list = list(views) if isinstance(views, (list, tuple)) else [views]
        if len(x_list) != self.num_views:
            raise ValueError(f"Expected {self.num_views} views, got {len(x_list)}")

        per_view = [self.mpff[i](x_list[i]) for i in range(self.num_views)]
        stacked = torch.stack(per_view, dim=1) + self.view_embedding
        denoised = self._domain_msa(stacked)

        fused_2d, _ = self._weighted_group_fusion(denoised, self.idx_2d, self.intra2d_score)
        fused_3d, _ = self._weighted_group_fusion(denoised, self.idx_3d, self.intra3d_score)

        q2 = fused_2d.unsqueeze(1)
        q3 = fused_3d.unsqueeze(1)
        c2, _ = self.cross_attn(q2, q3, q3)
        c3, _ = self.cross_attn(q3, q2, q2)
        c2 = c2.squeeze(1)
        c3 = c3.squeeze(1)
        cross_token = 0.5 * (c2 + c3)

        hier_tokens = torch.stack([fused_2d, fused_3d, c2, c3, cross_token], dim=1)
        hier_tokens = self.cross_norm(hier_tokens)
        refined = self.transformer(hier_tokens)

        view_logits = self.view_weights_fc(denoised.reshape(denoised.size(0), -1))
        gated_bias = torch.sigmoid(self.view_bias_gate) * self.view_attention_bias
        view_logits = view_logits + gated_bias.unsqueeze(0)
        view_weights = torch.softmax(view_logits, dim=-1)
        weighted_view_token = torch.sum(denoised * view_weights.unsqueeze(-1), dim=1)

        token_scores = self.token_score_fc(refined).squeeze(-1)
        token_weights = torch.softmax(token_scores, dim=1).unsqueeze(-1)
        fused_token = torch.sum(refined * token_weights, dim=1)

        fused_output = self.final_proj(torch.cat([fused_token, weighted_view_token], dim=-1))
        return fused_output, view_weights


ATTENTION_FACTORIES = {
    "linear_projection": lambda num_views, feature_dim, is_sharedspecific: MultiViewLinearProjectionAttention(
        num_views, feature_dim, is_sharedspecific
    ),
    "se_attention": lambda num_views, feature_dim, is_sharedspecific: MultiViewSEAttention(
        num_views, feature_dim, is_sharedspecific
    ),
    "eca_attention": lambda num_views, feature_dim, is_sharedspecific: MultiViewECAAttention(
        num_views, feature_dim, is_sharedspecific
    ),
    "adaptive_attention": lambda num_views, feature_dim, is_sharedspecific: AdaptiveMultiViewAttention(
        num_views, feature_dim, is_sharedspecific
    ),
    "cross_attention": lambda num_views, feature_dim, is_sharedspecific: MultiViewCrossAttentionWrapper(
        num_views, feature_dim, is_sharedspecific
    ),
    "csam": lambda num_views, feature_dim, is_sharedspecific: CSAMDecoder(
        feature_dim, num_views=num_views, is_sharedspecific=is_sharedspecific
    ),
    "dsam": lambda num_views, feature_dim, is_sharedspecific: CSAMDecoder(
        feature_dim, num_views=num_views, is_sharedspecific=is_sharedspecific
    ),
    "DSAM": lambda num_views, feature_dim, is_sharedspecific: CSAMDecoder(
        feature_dim, num_views=num_views, is_sharedspecific=is_sharedspecific
    ),
    # MVCA / Enhanced-CSAM variants.
    # "csam_enhanced" is kept as a backward-compatible alias of the full MVCA.
    "csam_enhanced": lambda num_views, feature_dim, is_sharedspecific: EnhancedCSAMDecoder(
        feature_dim,
        num_views=num_views,
        is_sharedspecific=is_sharedspecific,
        ablation_mode="full",
    ),
    "mvca_full": lambda num_views, feature_dim, is_sharedspecific: EnhancedCSAMDecoder(
        feature_dim,
        num_views=num_views,
        is_sharedspecific=is_sharedspecific,
        ablation_mode="full",
    ),
    "mvca_channel_only": lambda num_views, feature_dim, is_sharedspecific: EnhancedCSAMDecoder(
        feature_dim,
        num_views=num_views,
        is_sharedspecific=is_sharedspecific,
        ablation_mode="channel_only",
    ),
    "mvca_crossview_only": lambda num_views, feature_dim, is_sharedspecific: EnhancedCSAMDecoder(
        feature_dim,
        num_views=num_views,
        is_sharedspecific=is_sharedspecific,
        ablation_mode="crossview_only",
    ),
    # Short aliases, useful for quick command-line/config experiments.
    "mvca_csam_only": lambda num_views, feature_dim, is_sharedspecific: EnhancedCSAMDecoder(
        feature_dim,
        num_views=num_views,
        is_sharedspecific=is_sharedspecific,
        ablation_mode="channel_only",
    ),
    "mvca_mha_only": lambda num_views, feature_dim, is_sharedspecific: EnhancedCSAMDecoder(
        feature_dim,
        num_views=num_views,
        is_sharedspecific=is_sharedspecific,
        ablation_mode="crossview_only",
    ),
}


class MultiviewDecoder(nn.Module):
    """
    Base class for multi-view decoders, supports different fusion modes.
    """

    def __init__(self, feature_dim, num_views=None, mode="concat"):
        super(MultiviewDecoder, self).__init__()
        self.mode = mode
        self.num_views = num_views
        self.feature_dim = feature_dim

    def add_fusion(self, *x_list):
        if not x_list:
            return None
        stacked_tensors = torch.stack(x_list, dim=0)
        return torch.sum(stacked_tensors, dim=0)

    def concat_fusion(self, *x_list):
        return torch.cat(x_list, dim=-1)

    def attention_fusion(self, *x_list, target_domains=None):
        views = list(x_list)
        return self.attention(views)

    def forward(self, *x_list, **kwargs):
        if self.num_views is not None and len(x_list) != self.num_views:
            raise ValueError(f"Expected {self.num_views} inputs, got {len(x_list)}")
        if self.mode == "add":
            return self.add_fusion(*x_list)
        if self.mode == "concat":
            return self.concat_fusion(*x_list)
        if self.mode == "attention":
            return self.attention_fusion(*x_list, **kwargs)
        raise ValueError("Invalid fusion mode")


class ConcatDecoder(MultiviewDecoder):
    """
    Simply concatenates input features from multiple views.
    """

    def __init__(self, feature_dim, num_views=None, mode="concat", method=None):
        super().__init__(feature_dim=feature_dim, num_views=num_views, mode=mode)
        if mode == "concat":
            input_size = feature_dim * num_views
        elif mode == "add":
            input_size = feature_dim
        else:
            raise ValueError("Unsupported mode for ConcatDecoder")
        self.linear = nn.Linear(input_size, feature_dim)

        # 轻量视图权重头：仅用于 is_weights_loss KL 正则监督，不影响融合逻辑
        if mode == "concat" and num_views is not None:
            self.view_weights_fc = nn.Sequential(
                nn.Linear(input_size, num_views),
            )
        else:
            self.view_weights_fc = None

    def forward(self, *x_list, **kwargs):
        fused_features = super().forward(*x_list, **kwargs)
        output = self.linear(fused_features)

        # 生成 weights 供 is_weights_loss 使用，与 AttentionDecoder 训练条件对齐
        if self.view_weights_fc is not None:
            weights = torch.softmax(self.view_weights_fc(fused_features), dim=-1)
        else:
            weights = None

        return output, weights


class AttentionDecoder(MultiviewDecoder):
    """
    Aligns multiple views using different attention strategies.
    """

    def __init__(
        self,
        feature_dim,
        num_views=None,
        is_sharedspecific=0,
        method="linear_projection",
        num_classes=7,
        selected_features=None,
    ):
        super().__init__(feature_dim=feature_dim, num_views=num_views, mode="attention")
        self.method = method
        if method == "DScombine":
            self.attention = MultiViewDSFusion(num_views, feature_dim, num_classes)
        elif method == "csam_hetero":
            self.attention = HeteroCSAMDecoder(
                feature_dim,
                num_views=num_views,
                is_sharedspecific=is_sharedspecific,
                selected_features=selected_features,
                use_view_embedding=False,
            )
        elif method == "csam_hetero_viewid":
            self.attention = HeteroCSAMDecoder(
                feature_dim,
                num_views=num_views,
                is_sharedspecific=is_sharedspecific,
                selected_features=selected_features,
                use_view_embedding=True,
            )
        elif method == "csam_domain_generalized":
            self.attention = DomainGeneralizedCSAMDecoder(
                feature_dim,
                num_views=num_views,
                is_sharedspecific=is_sharedspecific,
                selected_features=selected_features,
            )
        elif method == "csam_domain_generalized_base":
            self.attention = DomainGeneralizedCSAMDecoder(
                feature_dim,
                num_views=num_views,
                is_sharedspecific=is_sharedspecific,
                selected_features=selected_features,
                use_view_gain=False,
                use_view_embedding=False,
                use_view_bias=False,
            )
        elif method == "csam_domain_generalized_viewid":
            self.attention = DomainGeneralizedCSAMDecoder(
                feature_dim,
                num_views=num_views,
                is_sharedspecific=is_sharedspecific,
                selected_features=selected_features,
                use_view_gain=False,
                use_view_embedding=True,
                use_view_bias=False,
            )
        elif method == "csam_domain_generalized_viewid_bias":
            self.attention = DomainGeneralizedCSAMDecoder(
                feature_dim,
                num_views=num_views,
                is_sharedspecific=is_sharedspecific,
                selected_features=selected_features,
                use_view_gain=False,
                use_view_embedding=True,
                use_view_bias=True,
            )
        elif method == "csam_domain_generalized_hier":
            self.attention = DomainGeneralizedHierCSAMDecoder(
                feature_dim,
                num_views=num_views,
                is_sharedspecific=is_sharedspecific,
                selected_features=selected_features,
            )
        else:
            if method not in ATTENTION_FACTORIES:
                raise ValueError(f"Unknown attention type: {method}")
            self.attention = ATTENTION_FACTORIES[method](num_views, feature_dim, is_sharedspecific)

    def forward(self, *x_list, **kwargs):
        return super().forward(*x_list, **kwargs)