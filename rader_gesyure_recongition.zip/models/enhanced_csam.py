"""
Lightweight Enhanced CSAM / MVCA decoder for multi-view radar fusion.

This version adds explicit branch-ablation support for the MVCA study:
    - full:              channel-spatial branch + cross-view MHA branch
    - channel_only:      channel-spatial branch only
    - crossview_only:    cross-view MHA branch only

All variants keep the same encoder, learnable view-weight predictor and output
head. Therefore the ablation changes only the internal MVCA branch composition.
"""

import torch
import torch.nn as nn


class EnhancedCSAMBlock(nn.Module):
    """
    Lightweight local channel-spatial feature interaction block.

    The block keeps the original implementation used by the project:
    a 3x3 convolutional feature-mixing branch followed by channel attention.
    """

    def __init__(self, in_channels, reduction=16):
        super().__init__()
        reduced_channels = max(1, in_channels // reduction)

        self.branch3 = nn.Sequential(
            nn.Conv2d(
                in_channels,
                in_channels,
                kernel_size=3,
                padding=1,
                bias=False,
            ),
            nn.BatchNorm2d(in_channels),
            nn.ReLU(inplace=True),
        )

        self.channel_attn = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(in_channels, reduced_channels, 1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(reduced_channels, in_channels, 1, bias=False),
            nn.Sigmoid(),
        )

    def forward(self, x):
        x_ms = self.branch3(x)
        return x_ms * self.channel_attn(x_ms)


class MultiHeadCrossAttention(nn.Module):
    """
    Lightweight cross-view multi-head self-attention.

    Input shape:  (B, V, C)
    Output shape: (B, V, C)
    """

    def __init__(self, feature_dim, num_heads=4, dropout=0.1):
        super().__init__()
        self.feature_dim = int(feature_dim)
        self.num_heads = int(num_heads)

        if self.feature_dim % self.num_heads != 0:
            raise ValueError(
                f"feature_dim ({self.feature_dim}) must be divisible by "
                f"num_heads ({self.num_heads})"
            )

        self.attn = nn.MultiheadAttention(
            embed_dim=self.feature_dim,
            num_heads=self.num_heads,
            dropout=dropout,
            batch_first=True,
        )
        self.norm = nn.LayerNorm(self.feature_dim)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        if x.dim() != 3:
            raise ValueError(
                f"MultiHeadCrossAttention expects (B, V, C), got {tuple(x.shape)}"
            )

        attn_out, _ = self.attn(x, x, x, need_weights=False)
        return self.norm(x + self.dropout(attn_out))


class EnhancedCSAMDecoder(nn.Module):
    """
    MVCA fusion decoder with explicit ablation modes.

    Parameters
    ----------
    feature_dim : int
        Feature/token dimension C of each radar view.
    num_views : int, optional
        Number of input views V. Defaults to 5.
    is_sharedspecific : bool
        Kept for backward compatibility with the original project interface.
        It is not used by this decoder.
    ablation_mode : str
        One of:
        - "full": use both branches and average their weighted outputs.
        - "channel_only": use only the channel-spatial/local branch.
        - "crossview_only": use only the cross-view MHA branch.
    num_heads : int
        Number of attention heads for the cross-view MHA branch.

    Notes
    -----
    The view-weight predictor is intentionally preserved in every variant.
    This makes the ablation focus on whether the two MVCA branches are
    complementary, while keeping sample-adaptive view weighting unchanged.
    """

    _MODE_ALIASES = {
        "full": "full",
        "mvca_full": "full",
        "both": "full",
        "channel_only": "channel_only",
        "csam_only": "channel_only",
        "local_only": "channel_only",
        "crossview_only": "crossview_only",
        "mha_only": "crossview_only",
        "attention_only": "crossview_only",
    }

    def __init__(
        self,
        feature_dim,
        num_views=None,
        is_sharedspecific=False,
        ablation_mode="full",
        num_heads=4,
    ):
        super().__init__()
        del is_sharedspecific  # interface compatibility only

        self.feature_dim = int(feature_dim)
        self.num_views = int(num_views if num_views is not None else 5)
        self.num_heads = int(num_heads)

        requested_mode = str(ablation_mode).strip().lower()
        if requested_mode not in self._MODE_ALIASES:
            valid = sorted(set(self._MODE_ALIASES.values()))
            raise ValueError(
                f"Unknown MVCA ablation_mode={ablation_mode!r}. "
                f"Expected one of {valid}."
            )
        self.ablation_mode = self._MODE_ALIASES[requested_mode]

        # Instantiate only the branch(es) used by this variant. This makes the
        # architecture and parameter count reflect the actual ablation model.
        if self.ablation_mode in {"full", "channel_only"}:
            self.enhanced_csam = EnhancedCSAMBlock(
                self.feature_dim * self.num_views
            )
            self.pool = nn.AdaptiveAvgPool2d(1)
        else:
            self.enhanced_csam = None
            self.pool = None

        if self.ablation_mode in {"full", "crossview_only"}:
            self.cross_attention = MultiHeadCrossAttention(
                self.feature_dim,
                num_heads=self.num_heads,
            )
        else:
            self.cross_attention = None

        # Keep exactly the same output head for all ablation variants.
        self.output_head = nn.Sequential(
            nn.LayerNorm(self.feature_dim),
            nn.Dropout(0.3),
            nn.Linear(self.feature_dim, self.feature_dim),
        )

        # Keep the same sample-adaptive view-weight predictor for all variants.
        self.view_weights_fc = nn.Sequential(
            nn.Linear(self.feature_dim * self.num_views, 128),
            nn.ReLU(inplace=True),
            nn.Dropout(0.1),
            nn.Linear(128, self.num_views),
        )

    def _validate_views(self, views):
        if isinstance(views, (list, tuple)):
            x_list = list(views)
        else:
            x_list = [views]

        if len(x_list) == 0:
            raise ValueError("No views provided")
        if len(x_list) != self.num_views:
            raise ValueError(
                f"Expected {self.num_views} views, got {len(x_list)}"
            )

        first_shape = x_list[0].shape
        if len(first_shape) != 2:
            raise ValueError(
                f"Each view must have shape (B, C), got {tuple(first_shape)}"
            )

        batch_size, feature_dim = first_shape
        if feature_dim != self.feature_dim:
            raise ValueError(
                f"Expected feature_dim={self.feature_dim}, got {feature_dim}"
            )

        for idx, view in enumerate(x_list[1:], start=1):
            if view.dim() != 2:
                raise ValueError(
                    f"View {idx} must have shape (B, C), got {tuple(view.shape)}"
                )
            if view.shape[0] != batch_size or view.shape[1] != feature_dim:
                raise ValueError(
                    "All views must share the same (B, C). "
                    f"View 0={tuple(first_shape)}, view {idx}={tuple(view.shape)}"
                )

        return x_list

    def _channel_spatial_branch(self, stacked_views, view_weights):
        """Return the view-weighted local/channel-spatial branch token."""
        if self.enhanced_csam is None or self.pool is None:
            raise RuntimeError("Channel-spatial branch is disabled")

        batch_size, num_views, feature_dim = stacked_views.shape
        x = stacked_views.reshape(
            batch_size,
            num_views * feature_dim,
            1,
            1,
        )
        x_local = self.enhanced_csam(x)
        x_local = self.pool(x_local).flatten(1)
        local_view_tokens = x_local.reshape(
            batch_size,
            num_views,
            feature_dim,
        )
        return torch.sum(
            local_view_tokens * view_weights.unsqueeze(-1),
            dim=1,
        )

    def _cross_view_branch(self, stacked_views, view_weights):
        """Return the view-weighted cross-view MHA branch token."""
        if self.cross_attention is None:
            raise RuntimeError("Cross-view MHA branch is disabled")

        cross_tokens = self.cross_attention(stacked_views)
        return torch.sum(
            cross_tokens * view_weights.unsqueeze(-1),
            dim=1,
        )

    def forward(self, views):
        """
        Parameters
        ----------
        views : list[Tensor]
            V tensors with shape (B, C).

        Returns
        -------
        out : Tensor
            Fused feature with shape (B, C).
        view_weights : Tensor
            Sample-adaptive view weights with shape (B, V).
        """
        x_list = self._validate_views(views)
        batch_size = x_list[0].shape[0]

        stacked_views = torch.stack(x_list, dim=1)  # (B, V, C)

        view_logits = self.view_weights_fc(
            stacked_views.reshape(batch_size, -1)
        )
        view_weights = torch.softmax(view_logits, dim=-1)

        if self.ablation_mode == "full":
            channel_token = self._channel_spatial_branch(
                stacked_views,
                view_weights,
            )
            crossview_token = self._cross_view_branch(
                stacked_views,
                view_weights,
            )
            # Same two-branch averaging as the original full model.
            fused = 0.5 * (channel_token + crossview_token)

        elif self.ablation_mode == "channel_only":
            fused = self._channel_spatial_branch(
                stacked_views,
                view_weights,
            )

        elif self.ablation_mode == "crossview_only":
            fused = self._cross_view_branch(
                stacked_views,
                view_weights,
            )

        else:  # defensive; __init__ already validates the mode
            raise RuntimeError(
                f"Unexpected ablation mode: {self.ablation_mode}"
            )

        out = self.output_head(fused)
        return out, view_weights

    def extra_repr(self):
        return (
            f"feature_dim={self.feature_dim}, num_views={self.num_views}, "
            f"num_heads={self.num_heads}, ablation_mode={self.ablation_mode!r}"
        )