"""
ProtoNet分类头：替换原来的Linear classifier
训练时：CE loss + prototype contrastive loss
测试时：余弦距离匹配最近原型

插入位置：model.py
使用方式：
  1. 把这个文件放到 models/ 目录下
  2. 在 model.py 中 import 并替换 classifier
  3. 在 train.py 的 initialize_model 中根据 use_proto_head 参数启用
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class ProtoHead(nn.Module):
    """
    原型分类头：用余弦相似度替代线性分类器
    
    相比 Linear classifier 的优势：
    - 对类内分布分散的类（如Up）更鲁棒
    - 原型向量比权重矩阵更稳定
    - 支持在测试时用新样本更新原型（few-shot adaptation）
    
    训练时：同时计算 CE loss（主）+ proto contrastive loss（辅）
    测试时：对 fused_feature 做 L2 归一化后与原型做余弦相似度
    """

    def __init__(self, feature_dim: int, num_classes: int, temp: float = 10.0):
        """
        Args:
            feature_dim: 输入特征维度（对应 fc_size）
            num_classes: 类别数量
            temp: 余弦相似度的温度系数，越大分布越尖锐
        """
        super().__init__()
        self.feature_dim = feature_dim
        self.num_classes = num_classes
        self.temp = temp

        # 可学习的原型向量，初始化为随机单位向量
        self.prototypes = nn.Parameter(
            F.normalize(torch.randn(num_classes, feature_dim), dim=1)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: (B, feature_dim) 融合后的特征
        Returns:
            logits: (B, num_classes) 余弦相似度乘以温度系数
        """
        # L2归一化特征和原型
        x_norm = F.normalize(x, dim=1)                          # (B, D)
        proto_norm = F.normalize(self.prototypes, dim=1)        # (C, D)

        # 余弦相似度 × 温度 = logits
        logits = self.temp * torch.mm(x_norm, proto_norm.t())   # (B, C)
        return logits

    def proto_contrastive_loss(self, x: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        """
        原型对比损失：让同类特征靠近原型，异类特征远离原型
        
        Args:
            x: (B, feature_dim)
            targets: (B,) 类别标签
        Returns:
            loss: 标量
        """
        x_norm = F.normalize(x, dim=1)
        proto_norm = F.normalize(self.prototypes, dim=1)
        
        # 每个样本与所有原型的余弦相似度
        sim = torch.mm(x_norm, proto_norm.t())   # (B, C)
        
        # 用 CE loss 计算原型对比损失（和分类loss结构一致）
        loss = F.cross_entropy(self.temp * sim, targets)
        return loss

    @torch.no_grad()
    def update_prototypes_ema(self, x: torch.Tensor, targets: torch.Tensor,
                               momentum: float = 0.9):
        """
        用当前batch的样本指数移动平均更新原型（可选，训练时调用）
        
        Args:
            x: (B, feature_dim)
            targets: (B,) 类别标签
            momentum: EMA动量，越大原型更新越慢越稳定
        """
        x_norm = F.normalize(x.detach(), dim=1)
        for c in range(self.num_classes):
            mask = (targets == c)
            if mask.any():
                class_mean = x_norm[mask].mean(dim=0)
                # EMA更新
                self.prototypes.data[c] = (
                    momentum * self.prototypes.data[c] +
                    (1 - momentum) * class_mean
                )
                # 重新归一化
                self.prototypes.data[c] = F.normalize(
                    self.prototypes.data[c].unsqueeze(0), dim=1
                ).squeeze(0)