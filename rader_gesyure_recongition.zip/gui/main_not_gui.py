import os
import yaml
import threading
import argparse
import torch
import atexit
import queue
import csv
import math
from datetime import datetime
from queue import Queue 
import sys

# Ensure the parent `code/` directory is on sys.path so imports like
# `import utils.*` work when this script is run from the repository root.
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import utils.globalvar as gl
from bin.train import TrainRunner
from bin.train import TestRunner
import logging

# 定义全局日志开关
GLOBAL_LOG_ENABLE = True
 
# 全局日志等级
GLOBAL_LOG_LEVEL = logging.NOTSET
 
# 定义不同级别的日志颜色
COLORS = {
    'DEBUG': '\033[1;32m',  # 绿色
    'INFO': '\033[1;34m',  # 蓝色
    'WARNING': '\033[38;5;208m',  # 橙色
    'ERROR': '\033[1;31m',  # 红色
    'CRITICAL': '\033[1;35m',  # 紫色
}
 
def get_logger(name, log_level=logging.INFO):
    logger = logging.getLogger(name)
 
    if not GLOBAL_LOG_ENABLE:
        logger.disabled = True
        return logger
 
    if GLOBAL_LOG_LEVEL > logging.NOTSET:
        log_level = GLOBAL_LOG_LEVEL
 
    logger.setLevel(log_level)
    # 定义控制台输出的handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(log_level)
 
    # 定义不同级别的日志输出颜色
    for level, color in COLORS.items():
        logging.addLevelName(getattr(logging, level), f'{color}{level}{color}')
 
    # 定义输出格式
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s: %(message)s')
    # 定义控制台输出的格式
    console_handler.setFormatter(formatter)
 
    # 添加handler
    logger.addHandler(console_handler)
 
    return logger

class WorkerThread(threading.Thread):
    def __init__(self, task_queue, shutdown_event):
        super().__init__()
        self.task_queue = task_queue
        self.shutdown_event = shutdown_event
        self.daemon = True  # 设置为守护线程，主程序退出时自动结束

    def run(self):
        logger.info("工作线程启动。")
        while not self.shutdown_event.is_set():
            try:
                # 使用较短的超时，以便能及时检查关闭事件
                task, args = self.task_queue.get(timeout=0.5)
                # logger.info(f"执行任务: {task.__name__}")
                try:
                    task(*args)
                except Exception as e:
                    logger.error(f"执行任务 {task.__name__} 时出错: {e}")
                self.task_queue.task_done()
            except queue.Empty:
                continue
        logger.info("工作线程终止。")

def start_training(args):
    """
    开始训练过程。如果训练路径和方法正确配置，则启动训练任务；否则提示错误。
    """
    if args.train_and_vali_data_dir and args.fusion_mode:
        collector = TrainRunner('Listener', args.train_and_vali_data_dir, args.train_ratio, args)
        collector.start()
        update_train_progress(args)
        collector.join()   # 等待训练线程完成
    else:
        logger.info('请检查训练路径和选中方法!')

def start_testing(args):
    """
    开始测试过程。如果测试路径正确配置，则启动测试任务；否则提示错误。
    """

    if args.test_data_dir_and_model:
        collector = TestRunner('Listener',args.test_data_dir_and_model, args)
        collector.start()
        update_test_progress(args)
        collector.join()   # 等待训练线程完成
    else:
       logger.info('请检查路径和选中方法!')

def update_test_progress(args):
    """
    更新测试进度界面，包括打印信息和绘制图表。
    """
    update_progress(args, 
        update_callback=lambda: update_test_progress(args), 
        print_end_message='---- Testing complete!  ----',
        confusion_matrix1=args.confusion_train,
        confusion_matrix2=args.confusion_val
    )

def update_train_progress(args):
    """
    更新训练进度界面，包括打印信息和绘制图表。
    """
    update_progress(args,
        update_callback=lambda: update_train_progress(args), 
        print_end_message='---- Training Complete! ----',
        confusion_matrix1=args.confusion_train,
        confusion_matrix2=args.confusion_val
    )

def cleanup():
    logger.info("执行清理操作，设置关闭事件。")
    shutdown_event.set()
    worker.join()  # 等待工作线程结束
    
def update_progress(args, update_callback, print_end_message, confusion_matrix1, confusion_matrix2, enable_ui_callback=None):
    try:
        # 从队列中获取字符串，增加超时以避免阻塞过长
        print_str = args.print_queue.get(timeout=5)
        logger.info(f"{print_str}")
    except queue.Empty:
        task_queue.put((update_callback, ()))
        logger.warning("print_queue 获取超时，没有数据可处理。")
        return

    if print_str != print_end_message:
        # 将 update_callback 任务添加到任务队列
        task_queue.put((update_callback, ()))
        # logger.info("已将 update_callback 添加到任务队列。")
    elif enable_ui_callback:
        # 将 enable_ui_callback 任务添加到任务队列
        task_queue.put((enable_ui_callback, ()))
        # logger.info("已将 enable_ui_callback 添加到任务队列。")

    

# 读取 YAML 文件
def load_config(yaml_path):
    # Try multiple sensible locations for the config file:
    # 1. As given (could be absolute or relative to CWD)
    # 2. Relative to the `code/` directory (this file's parent)
    # 3. If the given path begins with a leading `code/`, strip it and
    #    resolve relative to the `code/` directory to avoid `code/code/...`.

    candidates = []
    candidates.append(yaml_path)

    code_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    # If yaml_path starts with 'code/' or 'code\', strip that prefix
    yaml_rel = yaml_path
    if not os.path.isabs(yaml_path):
        if yaml_path.startswith('code' + os.sep) or yaml_path.startswith('code/'):
            # Remove the leading 'code/' part
            yaml_rel = yaml_path.split(os.sep, 1)[1] if os.sep in yaml_path else yaml_path.partition('/')[2]
        candidates.append(os.path.join(code_dir, yaml_rel))

    # Check candidates for existence and return first valid
    for c in candidates:
        try_path = os.path.abspath(c)
        if os.path.exists(try_path):
            with open(try_path, 'r', encoding='utf-8') as file:
                return yaml.safe_load(file)

    # If none found, raise a clear error listing attempted paths
    raise FileNotFoundError(f"Config file not found. Tried: {candidates}")


def extract_top1_from_confusion_matrix(confusion_path):
    """Return (top1_percent, correct, total) from confusion matrix text file."""
    if not os.path.exists(confusion_path):
        return None

    total = 0
    correct = 0
    row_idx = 0
    with open(confusion_path, "r", encoding="utf-8") as f:
        for raw_line in f:
            line = raw_line.strip()
            if not line:
                continue
            parts = [int(x) for x in line.split()]
            if not parts:
                continue
            total += sum(parts)
            if row_idx < len(parts):
                correct += parts[row_idx]
            row_idx += 1

    if total <= 0:
        return None
    return (correct * 100.0 / total, int(correct), int(total))


def write_multi_run_summary_csv(args, run_records):
    """Write summary + per-run records to CSV and return file path."""
    summary_dir = os.path.join("logs", "multi_run_summary")
    os.makedirs(summary_dir, exist_ok=True)

    cfg_name = os.path.splitext(os.path.basename(getattr(args, "config", "config")))[0]
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_csv = os.path.join(summary_dir, f"{cfg_name}_{ts}.csv")

    valid = [r for r in run_records if r["top1"] is not None]
    expected_runs = int(getattr(args, "experiment_runs", len(run_records)))
    valid_n = len(valid)

    mean_top1 = None
    std_top1 = None
    best = None
    worst = None

    if valid_n > 0:
        values = [r["top1"] for r in valid]
        mean_top1 = sum(values) / valid_n
        if valid_n > 1:
            std_top1 = math.sqrt(sum((x - mean_top1) ** 2 for x in values) / (valid_n - 1))
        else:
            std_top1 = 0.0
        best = max(valid, key=lambda x: x["top1"])
        worst = min(valid, key=lambda x: x["top1"])

    with open(out_csv, "w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["metric", "value"])
        writer.writerow(["expected_runs", expected_runs])
        writer.writerow(["completed_runs", len(run_records)])
        writer.writerow(["valid_top1_runs", valid_n])
        writer.writerow(["mean_top1_percent", f"{mean_top1:.6f}" if mean_top1 is not None else "N/A"])
        writer.writerow(["std_top1_percent", f"{std_top1:.6f}" if std_top1 is not None else "N/A"])
        writer.writerow(["best_top1_percent", f"{best['top1']:.6f}" if best else "N/A"])
        writer.writerow(["best_run_index", best["run_index"] if best else "N/A"])
        writer.writerow(["best_seed", best["seed"] if best else "N/A"])
        writer.writerow(["best_run_dir", best["run_dir"] if best else "N/A"])
        writer.writerow(["worst_top1_percent", f"{worst['top1']:.6f}" if worst else "N/A"])
        writer.writerow(["worst_run_index", worst["run_index"] if worst else "N/A"])
        writer.writerow(["worst_seed", worst["seed"] if worst else "N/A"])
        writer.writerow(["worst_run_dir", worst["run_dir"] if worst else "N/A"])

        writer.writerow([])
        writer.writerow(["run_index", "seed", "top1_percent", "correct", "total", "status", "run_dir"])
        for r in run_records:
            writer.writerow([
                r["run_index"],
                r["seed"],
                f"{r['top1']:.6f}" if r["top1"] is not None else "N/A",
                r["correct"] if r["correct"] is not None else "N/A",
                r["total"] if r["total"] is not None else "N/A",
                r["status"],
                r["run_dir"],
            ])

    return out_csv


if __name__ == "__main__":
    gl._init()
    logger = get_logger("main")
    metrics = {
        'loss_train': Queue(),
        'acc_train': Queue(),
        'loss_val': Queue(),
        'acc_val': Queue(),
        'confusion_train': Queue(),
        'confusion_val': Queue(),
        'print_queue': Queue(),
    }

    # 如果还想支持命令行覆盖 YAML 配置
    parser = argparse.ArgumentParser(description='Config')
    parser.add_argument('--config', default='code/examples/conf_mvca_full.yaml', type=str, help='Path to config file')
    parser.add_argument('--train-model', default='', type=str, help='Path to an existing checkpoint (.pth.tar) for continued training')
    parser.add_argument('--seed', default=42, type=int, help='Random seed')
    parser.add_argument('--deterministic', default=False, action='store_true', help='Enable deterministic cuDNN')
    config = load_config(parser.parse_args().config)
    parser.set_defaults(seed=config.get('seed', 42), deterministic=config.get('deterministic', False))
    # 添加所有 YAML 参数支持命令行覆盖
    for key, value in config.items():
        if not isinstance(key, str):
            logger.warning("Skip non-string top-level config key: %r" % (key,))
            continue
        if key in ('seed', 'deterministic'):
            continue
        arg_type = type(value) if value is not None else str  # 推断类型
        parser.add_argument(f'--{key.replace("_", "-")}', default=value, type=arg_type)

    # 动态添加 metrics 参数
    for key, value in metrics.items():
        # 推断参数类型。如果是 Queue 或复杂类型，设置为 str
        arg_type = str if isinstance(value, (Queue, dict, list)) else type(value)
        parser.add_argument(f'--{key.replace("_", "-")}', default=value, type=arg_type)

    # 解析参数
    args = parser.parse_args()

    # Optional: continue training from an existing checkpoint path.
    # TrainRunner reads this value via gl.get_value('train_model').
    if isinstance(getattr(args, 'train_model', ''), str) and args.train_model.strip():
        gl.set_value('train_model', args.train_model.strip())
        logger.info(f"Resume training from: {gl.get_value('train_model')}")


    # Enforce YAML priority for reproducibility controls.
    base_seed = int(config.get('seed', getattr(args, 'seed', 123)))
    args.deterministic = bool(config.get('deterministic', getattr(args, 'deterministic', False)))
    args.random_init = bool(config.get('random_init', getattr(args, 'random_init', False)))
    args.experiment_runs = max(1, int(config.get('experiment_runs', getattr(args, 'experiment_runs', 1))))

    # Set random seeds per run (supports repeated experiments with random initialization)
    import random
    import numpy as np
    deterministic = bool(getattr(args, 'deterministic', False))
    args.save_path = ''
    # 创建任务队列
    task_queue = Queue()

    # 创建关闭事件
    shutdown_event = threading.Event()

    # 创建并启动工作线程
    worker = WorkerThread(task_queue, shutdown_event)
    worker.start()
    # 注册清理函数
    atexit.register(cleanup)

    run_records = []

    for i in range(args.experiment_runs):
        run_seed = int.from_bytes(os.urandom(4), 'little') if args.random_init else base_seed
        args.seed = int(run_seed)
        random.seed(args.seed)
        np.random.seed(args.seed)
        torch.manual_seed(args.seed)
        torch.cuda.manual_seed_all(args.seed)
        torch.backends.cudnn.deterministic = deterministic
        torch.backends.cudnn.benchmark = not deterministic
        logger.info(f"Run {i + 1}/{args.experiment_runs}: Seed={args.seed}, deterministic={deterministic}, random_init={args.random_init}")

        start_training(args)
        save_basename = os.path.basename(args.save_path) if isinstance(args.save_path, (str, bytes, os.PathLike)) else ''
        args.test_data_dir_and_model =[args.test_data_dir, [save_basename]]
        start_testing(args)

        confusion_path = os.path.join(args.save_path, 'output', 'confusion_matrix.txt')
        top1_pack = extract_top1_from_confusion_matrix(confusion_path)
        if top1_pack is None:
            run_records.append({
                'run_index': i + 1,
                'seed': int(args.seed),
                'top1': None,
                'correct': None,
                'total': None,
                'status': 'missing_metrics',
                'run_dir': args.save_path,
            })
            logger.warning(f"Run {i + 1}: missing confusion_matrix.txt or empty matrix at {confusion_path}")
        else:
            top1, correct, total = top1_pack
            run_records.append({
                'run_index': i + 1,
                'seed': int(args.seed),
                'top1': float(top1),
                'correct': int(correct),
                'total': int(total),
                'status': 'ok',
                'run_dir': args.save_path,
            })
            logger.info(f"Run {i + 1} Top-1={top1:.4f}% ({correct}/{total})")
        # 等待任务队列中的所有任务完成
    task_queue.join()
    summary_csv = write_multi_run_summary_csv(args, run_records)
    logger.info(f"多次实验汇总已写入: {summary_csv}")
    logger.info("所有任务已完成。")
