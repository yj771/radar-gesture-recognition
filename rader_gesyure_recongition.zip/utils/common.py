import os
import time
import yaml
import numpy as np
import torch
from datetime import datetime

def accuracy(output, target, topk=(1,)):
    maxk = max(topk)
    batch_size = target.size(0)

    _, pred = output.topk(maxk, 1, True, True)
    pred = pred.t()
    # print(pred)
    correct = pred.eq(target.view(1, -1).expand_as(pred))
    # print(correct)

    res = []
    for k in topk:
        correct_k = correct[:k].contiguous().view(-1).float().sum(0, keepdim=True)
        res.append(correct_k.mul_(100.0 / batch_size))
    return res

# 更新混淆矩阵
def confusion_matrix_compute(preds, labels, conf_matrix):
    
    for p, t in zip(preds, labels):
        conf_matrix[p, t] += 1
    return conf_matrix


def freeze_model_params(model):
    """
    冻结模型参数
    :param model: 模型对象
    """
    for name, param in model.named_parameters():
        if 'fc' in name:
            param.requires_grad = False

def save_training_results(save_path, train_loss, train_acc, val_loss, val_acc, train_cm, val_cm):
    """
    保存训练结果
    :param save_path: 保存路径
    :param train_loss: 训练损失
    :param train_acc: 训练准确率
    :param val_loss: 验证损失
    :param val_acc: 验证准确率
    :param train_cm: 训练混淆矩阵
    :param val_cm: 验证混淆矩阵
    """
    output_dir = os.path.join(save_path, 'output')
    np.savetxt(os.path.join(output_dir, 'curve.txt'), 
               (train_loss, train_acc, val_loss, val_acc), fmt='%.6f')
    np.savetxt(os.path.join(output_dir, 'train_cmat.txt'), train_cm.T, fmt='%d')
    np.savetxt(os.path.join(output_dir, 'val_cmat.txt'), val_cm.T, fmt='%d')

# lr_step设置为100 这句话执行不了的。动态降低学习率
def adjust_learning_rate(optimizer, lr_step, epoch):
    if not epoch % lr_step and epoch:
        for param_group in optimizer.param_groups:
            param_group['lr'] = param_group['lr'] * 0.6
    return optimizer


# Load YAML content into a dictionary  
def load_yaml_to_dict(file_path):  
    with open(file_path, 'r') as file:  
        return yaml.safe_load(file)  

# Update args with values from the loaded YAML  
def update_args_from_yaml(args, yaml_data):  
    for key, value in yaml_data.items():  
        if hasattr(args, key):  
            setattr(args, key, value)  
            
# Identify serializable types  
def is_serializable(value):  
    """Check if the value is serializable to YAML."""  
    serializable_types = (str, int, float, bool, list, tuple, dict, type(None))  # Basic serializable types  
    return isinstance(value, serializable_types)
  
# Save args to YAML  
def save_args_to_yaml(args, save_path):  
    args_dict = vars(args)  # Convert Namespace to dictionary  
    # Define types to exclude (e.g., queue.Queue)  
    # Filter out non-serializable values and those with attributes starting with double underscores  
    filtered_args = {  
        k: v for k, v in args_dict.items()  
        if is_serializable(v) and not k.startswith('__')  
    } 
    with open(save_path, 'w') as yaml_file:  
        yaml.dump(filtered_args, yaml_file, default_flow_style=False) 

def build_directory_structure(selected_features, optional_features, fusion_mode, method):
    # 判断特征是否为 "all"
    selected_features = sorted(selected_features) 
    if selected_features == sorted(optional_features):
        features_dir = "all"
    else:
        features_dir = "_".join(selected_features)

    # 处理fusion_mode
    # 假设fusion_mode只有一个父模式和对应子模式列表（根据你实际逻辑可调整）
    if fusion_mode:
        parent_dir = fusion_mode
        # 对子选项进行处理，这里假设只有互斥的一个被选中，或无子项
        if method and len(method) > 0:
            # 假设互斥只会有一个child选中
            child_dir = method 
            # 合成路径
            final_path = os.path.join(features_dir, parent_dir, child_dir)
        else:
            # 无子项的父模式
            final_path = os.path.join(features_dir, parent_dir)
    else:
        # 无fusion_mode则只有特征目录
        final_path = features_dir

    # 获取当前时间作为目录名的一部分
    now_str = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    final_path = os.path.join(final_path, now_str)

    return final_path


def profile_model(model, input_feature_shapes, selected_features, device, warmup=10, repeats=50):
    """
    分析模型的 GFLOPS / Params / Latency。

    Args:
        model:        PyTorch 模型 (nn.Module)
        input_feature_shapes: 特征名 -> 形状 的字典 (不含 batch 维度)
        selected_features:    使用的特征名列表
        device:       torch device
        warmup:       GPU warmup 次数
        repeats:      测时重复次数

    Returns:
        dict: {"params_M": ..., "gflops": ..., "latency_ms": ...}
    """
    batch_size = 1

    # ---- 构造 dummy input --------------------------------------------------
    dummy = {}
    for feat in selected_features:
        shape = list(input_feature_shapes[feat])
        if shape[0] == 1 and len(shape) == 4 and shape[2:] == [64, 64]:
            # RDT 类 3D 特征：(seq, C, H, W) -> (B, seq, C, H, W)
            shape = [batch_size] + shape
        else:
            shape = [batch_size] + shape
        dummy[feat] = torch.randn(*shape, device=device)

    # ---- Params ------------------------------------------------------------
    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    params_M = total_params / 1e6

    # ---- GFLOPS ------------------------------------------------------------
    gflops = 0.0
    try:
        from thop import profile
        model.eval()
        with torch.no_grad():
            flops, _ = profile(model, inputs=(dummy,), verbose=False)
        gflops = flops / 1e9
    except Exception as e:
        print(f"[profile_model] thop failed: {e}")
    finally:
        # THOP may register total_ops / total_params as persistent buffers.
        # Remove them so they cannot leak into model.state_dict() checkpoints.
        for module in model.modules():
            for attr in ("total_ops", "total_params"):
                if attr in getattr(module, "_buffers", {}):
                    del module._buffers[attr]
                elif hasattr(module, attr):
                    try:
                        delattr(module, attr)
                    except Exception:
                        pass

    # ---- Latency -----------------------------------------------------------
    latency_ms = 0.0
    model.eval()

    # 预热
    with torch.no_grad():
        for _ in range(warmup):
            _ = model(dummy)

    # 计时
    if device.type == 'cuda':
        start = torch.cuda.Event(enable_timing=True)
        end = torch.cuda.Event(enable_timing=True)
        torch.cuda.synchronize()
        start.record()
        with torch.no_grad():
            for _ in range(repeats):
                _ = model(dummy)
        end.record()
        torch.cuda.synchronize()
        latency_ms = start.elapsed_time(end) / repeats
    else:
        start = time.perf_counter()
        with torch.no_grad():
            for _ in range(repeats):
                _ = model(dummy)
        latency_ms = (time.perf_counter() - start) / repeats * 1000.0

    return {
        "params_M": params_M,
        "trainable_M": trainable_params / 1e6,
        "gflops": gflops,
        "latency_ms": latency_ms,
    }
