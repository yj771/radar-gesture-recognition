class AverageMeter(object):
	def __init__(self):
		self.reset()

	def reset(self):
		self.val = 0
		self.avg = 0
		self.sum = 0
		self.count = 0

	def update(self, val, n=1):
		self.val = val
		self.sum += val * n
		self.count += n
		self.avg = self.sum / self.count

def minmaxscaler(data):
	# Normalize each sample independently to avoid cross-sample scale leakage.
	flat = data.view(data.size(0), -1)
	dmin = flat.min(dim=1, keepdim=True)[0]
	dmax = flat.max(dim=1, keepdim=True)[0]
	denom = (dmax - dmin).clamp(min=1e-6)
	norm = (flat - dmin) / denom
	return norm.view_as(data)